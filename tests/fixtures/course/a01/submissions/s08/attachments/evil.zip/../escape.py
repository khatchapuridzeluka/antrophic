print('escaped')
