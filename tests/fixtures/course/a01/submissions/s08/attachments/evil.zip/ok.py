print('fine')
